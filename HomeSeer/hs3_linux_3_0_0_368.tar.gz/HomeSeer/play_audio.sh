#!/bin/sh
aplay "$1"

