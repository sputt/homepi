#!/bin/sh
echo  running comand $1
$1 | aha
