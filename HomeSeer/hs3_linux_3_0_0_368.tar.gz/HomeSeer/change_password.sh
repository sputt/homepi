#!/bin/bash
# $1=user $2=current pass $3=new pass
./check_passwd $1 $2
if [ $? == 0 ]; then
# echo "everything ok to change password"
 usermod -p $(echo $3 | openssl passwd -1 -stdin) $1
 echo "Password changed successfully."
else
 echo "Current password incorrect."
fi

