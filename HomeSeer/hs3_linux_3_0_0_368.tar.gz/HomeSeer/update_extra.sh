# install anything extra after files are untarred
