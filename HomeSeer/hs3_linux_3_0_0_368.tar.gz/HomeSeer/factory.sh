#!/bin/bash
echo "This script will delete all user data, proceed? (YES/NO)"
read answer_input

if [ "$answer_input" != "YES" ]; then
 exit 0
fi
echo "Deleting user data..."
sudo rm wave_files/*
sudo rm Media/*
sudo rm Grammar/*
sudo rm Config/Selectors/*
sudo rm Config/settings.ini.bak
sudo rm Logs/*
sudo rm Data/Backup/*
sudo rm Config/Z-Wave.ini
sudo rm Data/*.hsd
sudo rm Data/Energy/Energy.hsd
sudo rm -rf Data/Z-Wave/*
sudo rm Wave/*
sudo rm ConfigBackup/*
sudo rmdir RestoreConfig
sudo rm html/*.zip
sudo rm -rf Updates3/*
sudo rm Config/settings.ini
sudo rm Config/hspi_HSTouch.ini
sudo rm Config/users.cfg
sudo rm ~/.bash_history
sudo rm Config/licenses.bin
sudo rm getfiles.sh
sudo rm html/*.json
