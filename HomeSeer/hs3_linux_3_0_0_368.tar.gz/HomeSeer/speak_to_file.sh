#!/bin/sh
flite -o "$1" -t "$2"
