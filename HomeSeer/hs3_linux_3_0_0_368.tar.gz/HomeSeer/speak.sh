#!/bin/sh
#flite -voice kal16 -t "$1"
pico2wave -w=temp.wav "$1"
aplay temp.wav

